﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Theme
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Page_PreInit(Object sender,EventArgs e)
        {
            if (Request.QueryString["Theme"]!=null)
            {
                Page.Theme = Request.QueryString["Theme"].ToString();
            }
        }
        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name = DropDownList1.SelectedItem.Text;
            Response.Redirect("~/Login.aspx?Theme=" + name);

        }
    }
}                                                                                                                                                                                                                                                             