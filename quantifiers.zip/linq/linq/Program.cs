﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace linq
{
    class Program
    {
      

        static void Main(string[] args)
        {
            //    string[] words = { "believe", "relief", "receipt", "field" };

            //    bool iAfterE = words.Any(w => w.Contains("ei"));

            //    Console.WriteLine("There is a word that contains in the list that contains 'ei': {0}", iAfterE);
            //int[] numbers = { 1, 11, 3, 19, 41, 65, 19 };

            // bool onlyOdd = numbers.All(n => n % 2 == 1);

            // Console.WriteLine("The list contains only odd numbers: {0}", onlyOdd);   

            //     Console.ReadLine();


            List<Department> dept = new List<Department>();
            dept.Add(new Department() { DeptID = 1, DeptName = "Marketing", Floor = 1 });
            dept.Add(new Department() { DeptID = 2, DeptName = "Sales", Floor = 2 });
            dept.Add(new Department() { DeptID = 3, DeptName = "Administration", Floor = 3 });
            dept.Add(new Department() { DeptID = 4, DeptName = "Accounts", Floor = 3 });
            dept.Add(new Department() { DeptID = 5, DeptName = "HR", Floor = 3 });

            List<Employee> emp = new List<Employee>();
            emp.Add(new Employee() { EmpID = 1, DeptID = 1, EmpName = "Ack Nolas" });
            emp.Add(new Employee() { EmpID = 2, DeptID = 4, EmpName = "Ark Pine" });
            emp.Add(new Employee() { EmpID = 3, DeptID = 3, EmpName = "Andra Simte" });
            emp.Add(new Employee() { EmpID = 4, DeptID = 4, EmpName = "Arry Lo" });
            emp.Add(new Employee() { EmpID = 5, DeptID = 3, EmpName = "Adhir Panj" });
            emp.Add(new Employee() { EmpID = 6, DeptID = 2, EmpName = "Athy K" });
            emp.Add(new Employee() { EmpID = 7, DeptID = 1, EmpName = "Aff Joe" });
            emp.Add(new Employee() { EmpID = 8, DeptID = 1, EmpName = "Au Lie" });

            //any-simple
            //string[] words = { "believe", "relief", "receipt", "field" };

            //bool iAfterE = words.Any(w => w.Contains("ei"));

            //Console.WriteLine("Is there any  word that contains  'ei' in the list : {0}", iAfterE);
            ////"group by any"
            //     var noEmp =
            //from d in dept
            //where !emp.Any(e => e.DeptID == d.DeptID)
            //select new { dId = d.DeptID, dNm = d.DeptName };

            //     Console.WriteLine("Departments having no Employees");
            //     foreach (var empl in noEmp)
            //     {
            //         Console.WriteLine("Dept ID - " + empl.dId + ", Dept Name - " + empl.dNm);


            //     }
            //all-simple
            //int[] numbers = { 1, 11, 3, 19, 41, 65, 19 };

            //bool onlyOdd = numbers.All(n => n % 2 == 1);

            //Console.WriteLine("The list contains only odd numbers: {0}", onlyOdd);
            //group by all
            //Console.WriteLine("All Employees have their names starting with 'A'");
            //bool chkName = emp.All(e =>
            //                   e.EmpName.StartsWith("A"));
            //Console.WriteLine("Result : " + chkName);

            //Console.ReadLine();

        }
        

    }
    class Department
    {
        public int DeptID { get; set; }
        public string DeptName { get; set; }
        public int Floor { get; set; }
    }

    class Employee
    {
        public int EmpID { get; set; }
        public int DeptID { get; set; }
        public string EmpName { get; set; }
    }
}

