﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSLearning1
{
    class Program
    {
        static void Main(string[] args)
        {
            staticexample se = new staticexample();
            staticexample.add(se.id = 10);
            staticexample.i = 10;
            se.id = 10;
            DerivedClass d = new DerivedClass();
            d.setLength(4);
            d.setWidth(5);
            int area = d.area();
            Console.WriteLine("Area = "+area);
            Console.WriteLine("Cost1 = " + ((iLearn1)d).cost(area));
            Console.WriteLine("Cost2 = " + ((iLearn2)d).cost(area));

            Console.ReadLine();
        }
    }
    class BaseClass
    {
        protected int lenght;
        protected int width;

        public void setLength(int l)
        {
            this.lenght = l;
        }
        public void setWidth(int w)
        {
            this.width = w;
        }
    }
    class DerivedClass:BaseClass,iLearn1,iLearn2{
        public int area()
        {
            return lenght * width;
        }

        int iLearn1.cost(int area)
        {
            return area*10;
        }

        int iLearn2.cost(int area)
        {
            return area * 20;
        }
    }

    interface iLearn1
    {
         int cost(int a);
    }
    interface iLearn2
    {
        int cost(int a);
    }
    public class staticexample
    {
        public static int i;
        public int id
        {
            get
            {
                return i;
            }
            set
            {
                i = value;
            }
        }
        public static void add(int i)
        {
            Console.WriteLine(i);
        }

    }
}
