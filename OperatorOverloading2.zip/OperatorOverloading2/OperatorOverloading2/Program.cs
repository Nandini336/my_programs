﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OperatorOverloading2
{
    class Program
    {
        static void Main(string[] args)
        {
            OperatorOverloading2 op1 = new OperatorOverloading2(5,150);
            OperatorOverloading2 op2 = new OperatorOverloading2(3, 100);

            OperatorOverloading2 op3 = op1 * op2;

            op3.Display();

            Console.ReadLine();
        }
    }
    class OperatorOverloading2
    {
        int id;
        double grade;
        public OperatorOverloading2(int id,double grade)
        {
            this.id = id;
            this.grade = grade;
        }
        public void Display()
        {
            Console.WriteLine("ID :"+id +"Grade :"+grade);
            
        }
        public static OperatorOverloading2 operator *(OperatorOverloading2 op1,OperatorOverloading2 op2)
        {
            OperatorOverloading2 newOperator = new OperatorOverloading2(op1.id*op2.id,op1.grade*op2.grade);
            return newOperator;
        }
    }
}
