﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SealedClass
{
    class Program
    {
        static void Main(string[] args)
        {
            sealedClass sc = new sealedClass();
        }
    }

    sealed class sealedClass
    {
        public virtual void  sealedMethod()
        {

        }
    }

    class derivedClass : sealedClass
    {
        public sealed override void sealedMethod()
        {

        }
    }
}
