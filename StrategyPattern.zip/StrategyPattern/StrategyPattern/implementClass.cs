﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern
{
    class implementClass
    {
        private InterfaceClass setNumber;

        public void set(InterfaceClass num)
        {
            this.setNumber = num;
        }

        public void display()
        {
            setNumber.test();
        }
    }
}
