﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern
{
    class Program
    {
        static void Main(string[] args)
        {

            InterfaceClass ic = null;
            implementClass imp = new implementClass();
            while(true){
               Console.WriteLine("1.First 2.Second 3.Third");
               string input = Console.ReadLine();
            switch (input)
            {
                    case "1":ic = new FirstClass();
                        imp.set(ic);
                        imp.display();
                        break;
                     case "2":
                        ic = new SecondClass();
                        imp.set(ic);
                        imp.display();
                        break;
                    case "3":
                        ic = new ThirdClass();
                        imp.set(ic);
                        imp.display();
                        break;
                    default:Console.Write("Please select a number");
                        break;
             }
                
        }
        }
    }
}
