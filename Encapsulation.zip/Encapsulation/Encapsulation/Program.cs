﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Encapsulation
{
    class Program
    {
        static void Main(string[] args)
        {
            StudentClass sc = new StudentClass();
            sc.id = 4;
            sc.name = "nandini";

            Console.WriteLine(sc.id);
            Console.WriteLine(sc.name);
        }
    }
    class StudentClass
    {
        private int studentId;
        private string studentName;

        public int id
        {
            get
            {
                return studentId;
            }
            set
            {
                studentId = value;
            }
        }
        public string name
        {
            get
            {
                return studentName;
            }
            set
            {
                studentName = value;
            }
        }
    }
}
