﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
          
            DeafultConstructor dc1 = new DeafultConstructor("nandini");
            DeafultConstructor dc2 = new DeafultConstructor(dc1);

            DeafultConstructor pc = new DeafultConstructor(2,3);
            //modifierConstructor mc = new modifierConstructor();

            Console.ReadLine();
        }
    }
    class DeafultConstructor{
        string name;
       
        public DeafultConstructor(int x,int y)
        {
            Console.WriteLine("Parameter Constructor"+(x+y));
        }
        static DeafultConstructor()
        {
            Console.WriteLine("Static Constructor");
        }
        public DeafultConstructor(DeafultConstructor d)
        {
            name = d.name;
            Console.WriteLine(name);
        }
        public DeafultConstructor(string name)
        {
            this.name = name;
            
        }
    }
    class modifierConstructor
    {
        private modifierConstructor()
        {
            Console.WriteLine("Modifier Constructor");
        }
    }
}
