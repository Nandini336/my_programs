﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FunctionOverloading
{
    class Program
    {
        static void Main(string[] args)
        {
            FunctionalOverLoad f = new FunctionalOverLoad();
            f.intSum(2, 3);
            f.intSum(2.2);
            f.intSum("nandini");
            Console.ReadKey();
        }
    }
    class FunctionalOverLoad
    {
        public void intSum(int first,int second)
        {
            Console.WriteLine("Int: {0}", first);
        }
        public void intSum(double first)
        {
            Console.WriteLine("Double: {0}", first);
        }
        public void intSum(string first)
        {
            Console.WriteLine("String: {0}", first);
        }
    }
}
