﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OperatorOverloading
{
    class Program
    {
        static void Main(string[] args)
        {
            operatorOverloading o1 = new operatorOverloading(2,95);
            operatorOverloading o2 = new operatorOverloading(3,100);
            operatorOverloading o3 = o1 + o2;

            o3.display();
            Console.ReadKey();


        }
    }
    class operatorOverloading
    {
        public int Id;
        public double Grade;

        public operatorOverloading(int id, double grade)
        {
            this.Id = id;
            this.Grade = grade;
        }
        public void display()
        {
            Console.WriteLine("ID" + Id);
            Console.WriteLine("Grade" + Grade);
        }
        public static operatorOverloading operator +(operatorOverloading o1, operatorOverloading o2)
        {
            operatorOverloading newOperator1 = new operatorOverloading(o1.Id+o2.Id,o1.Grade+o2.Grade);
            return newOperator1;
        }


    }
}
