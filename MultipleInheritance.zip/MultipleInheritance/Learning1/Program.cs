﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Learning1
{
    class Program
    {
        static void Main(string[] args)
        {
            derivedClass d = new derivedClass();
            d.setWidth(10);
            d.setLength(2);
            int area = d.area();
            int cost = d.cost(area);
            Console.WriteLine(area);
            Console.WriteLine(cost);
            Console.ReadKey();
        }
    }
  
    class baseClass
    {
        protected int lenght;
        protected int width;
        public void setWidth(int w)
        {
            width = w;
        }
        public void setLength(int l)
        {
            lenght = l;
        }

    }
    class derivedClass : baseClass,cost
    {
        public int area()
        {
            return lenght * width;
        }
        public int cost(int area)
        {
            return area * 70;
        }
    }

    public interface cost {
        int cost(int area);
    }
}
