﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOverriding
{
    class Program
    {
        static void Main(string[] args)
        {
            DerivedClass1 d1 = new DerivedClass1();
            DerivedClass2 d2 = new DerivedClass2();
            Console.WriteLine(d1.area());
            Console.WriteLine(d2.area());
            Console.ReadLine();

        }
    }

    class BaseProgram
    {
        public virtual int area()
        {
            return 0;
        }
    }
    class DerivedClass1:BaseProgram
    {
        public override int area()
        {
            return 5;
        }
    }
    class DerivedClass2 : BaseProgram
    {
        public override int area()
        {
            return 10;
        }
    }

}
