﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstraction
{
    class Program
    {
        static void Main(string[] args)
        {
            Abstract ab = new Abstract();
            ab.shape(9);

            ab.Area();

           
            Console.ReadLine();
        }
    }

    interface interfaceImplementation //for interface no need of override keyword
    {
        
         void Area();
       
    }
    abstract class NewAbstract //for interface no need of override keyword
    {
        public  void Area()
        {
            Console.WriteLine("Hi");
        }
    }

    class Abstract : NewAbstract
    {
        int s;
        public int shape(int x)
        {
            return s = x;
        }
        public override void Area()
        {
            Console.WriteLine(s*s);
        }
    }
}
